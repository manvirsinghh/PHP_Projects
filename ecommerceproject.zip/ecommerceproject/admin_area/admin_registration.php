
<?php

include '../includes/connect.php';
include '../functions/common_function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            overflow: hidden;
        }
    </style>
</head>

<body>
    <div class="container-fluid m-3">
        <h2 class="text-center mb-5">Admin Registration</h2>
        <div class="row d-flex justify-content-center ">
            <div class="col-lg-6 col-xl-5">
                <img src="../adminregsiter (1).jpeg" alt="Admin Registration" class="img-fluid h-75">
            </div>
            <div class="col-lg-6 col-xl-4 shadow-lg">
                <form action="" method="post" class="mt-3">
                    <div class="form-outline mb-4">
                        <label for="username" class="form-label fw-bold">Username</label>
                        <input type="text" id="username" name="username" placeholder="enter your username" required="required" class="form-control">
                    </div>
                    <div class="form-outline mb-4">
                        <label for="email" class="form-label fw-bold">Email</label>
                        <input type="email" id="email" name="email" placeholder="enter your email" required="required" class="form-control">
                    </div>
                    <div class="form-outline mb-4">
                        <label for="password" class="form-label fw-bold">Password</label>
                        <input type="password" id="password" name="password" placeholder="enter your password" required="required" class="form-control">
                    </div>
                    <div class="form-outline mb-4">
                        <label for="confirm_password" class="form-label fw-bold">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="enter your confirm_password" required="required" class="form-control">
                    </div>
                <div>
                    <input type="submit"class="bg-info py-2 px-3 border-0 rounded fw-bolder" name="admin_registration" value="Register">
                    <p class="small fw-bold mt-2 pt-1 fs-6">Don't have an account?<a href="admin_login.php" class="link-danger fw-bold">Login</a></p>
                </div>
                    
                </form>
            </div>
        </div>

    </div>
</body>

</html>
<?php

if(isset($_POST['admin_registration'])){
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];
$hash_password=password_hash($password,PASSWORD_DEFAULT);
$confirm_password=$_POST['confirm_password'];
//select query

$select_query="SELECT * FROM admin_table where admin_name='$username' or admin_email='$email'";
$result=mysqli_query($conn,$select_query);
$row_count=mysqli_num_rows($result);
if($row_count>0){
  echo "<script>alert('Username and Email already exist')</script>";

}
else if($password!=$confirm_password){
    echo "<script>alert('Password do not match')</script>";
  }
  else{
    $insert_query="INSERT INTO admin_table(admin_name,admin_email,admin_password) values('$username','$email','$hash_password')";
    $sql_execute=mysqli_query($conn,$insert_query);
    if($sql_execute) {
        echo "<script>alert('Registration successful')</script>";
        
        
  }
}
}
  ?>