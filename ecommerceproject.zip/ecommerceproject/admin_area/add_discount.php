<?php
include("../includes/connect.php");
include("../functions/common_function.php");
// ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
session_start();

// Handle form submission
if (isset($_POST['apply_discount'])) {
    $product_id = $_POST['product_id'];
    $discount_percentage = $_POST['discount_percentage'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Check if the product already has a discount applied
    $check_query = "SELECT * FROM product_discounts WHERE product_id = $product_id";
    $result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($result) > 0) {
        // If the product already has a discount, update it
        $update_query = "UPDATE product_discounts 
                         SET discount_percent = $discount_percentage, start_date = '$start_date', end_date = '$end_date'
                         WHERE product_id = $product_id";
        
        if (mysqli_query($conn, $update_query)) {
            echo "<script>alert('Discount updated successfully!'); window.location.href='index.php?view_products';</script>";
        } else {
            echo "<script>alert('Error updating discount.');</script>";
        }
    } else {
        // If the product doesn't have a discount, insert a new one
        $insert_query = "INSERT INTO product_discounts (product_id, discount_percent, start_date, end_date) 
                         VALUES ($product_id, $discount_percentage, '$start_date', '$end_date')";
        
        if (mysqli_query($conn, $insert_query)) {
            echo "<script>alert('Discount applied successfully!'); window.location.href='index.php?view_products';</script>";
        } else {
            echo "<script>alert('Error applying discount.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add/Update Discount</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Apply or Update Discount to Product</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="product_id" class="form-label">Select Product</label>
            <select name="product_id" class="form-select" required>
                <option value="">-- Choose Product --</option>
                <?php
                $products = mysqli_query($conn, "SELECT product_id, product_title FROM products");
                while ($product = mysqli_fetch_assoc($products)) {
                    echo "<option value='{$product['product_id']}'>{$product['product_title']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="discount_percentage" class="form-label">Discount Percentage (%)</label>
            <input type="number" name="discount_percentage" class="form-control" required min="1" max="100">
        </div>
        <div class="mb-3">
            <label for="start_date" class="form-label">Start Date</label>
            <input type="date" name="start_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="end_date" class="form-label">End Date</label>
            <input type="date" name="end_date" class="form-control" required>
        </div>
        <button type="submit" name="apply_discount" class="btn btn-primary">Apply/Update Discount</button>
        <a href="index.php" class="btn btn-secondary">Back</a>
    </form>
</body>
</html>
