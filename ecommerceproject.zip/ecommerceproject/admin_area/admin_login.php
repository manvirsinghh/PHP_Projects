<?php

include '../includes/connect.php';
include '../functions/common_function.php';
@session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            overflow: hidden;
        }
    </style>
</head>

<body>
    <div class="container-fluid m-3">
        <h2 class="text-center mb-5">Admin Login</h2>
        <div class="row d-flex justify-content-center ">
            <div class="col-lg-6 col-xl-5">
                <img src="../adminregsiter (1).jpeg" alt="Admin Registration" class="img-fluid h-100">
            </div>
            <div class="col-lg-6 col-xl-4 shadow-lg">
                <form action="" method="post" class="mt-3">
                    <div class="form-outline mb-4">
                        <label for="username" class="form-label fw-bold text-dark">Username</label>
                        <input type="text" id="username" name="username" placeholder="enter your username" required="required" class="form-control">
                    </div>
                   
                    <div class="form-outline mb-4">
                        <label for="password" class="form-label fw-bold text-dark">Password</label>
                        <input type="password" id="password" name="password" placeholder="enter your password" required="required" class="form-control">
                    </div>

                    
                <div>
                    <input type="submit"class="bg-info py-2 px-3 border-0 fw-bold rounded" name="admin_login" value="Login">
                    <p class="small fw-bold mt-2 pt-1 fs-6">Already have an account?<a href="admin_registration.php" class="link-danger fw-bold">Register</a></p>
                </div>
                    
                </form>
            </div>
        </div>

    </div>
</body>

</html>
<?php

if (isset($_POST['admin_login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM admin_table WHERE admin_name='$username'";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        // if (password_verify($password, $row['admin_password'])) {
        //     $_SESSION['username'] = $username;
            
        //     echo "<script>alert('Login successful');</script>";
        //     echo "<script>window.location.href='index.php';</script>";
        // } 
        if (password_verify($password, $row['admin_password'])) {
            $_SESSION['admin_username'] = $username; // Use admin-specific session
            $_SESSION['role'] = $row['role']; // Optional if you store role in DB
            echo "<script>alert('Login successful');</script>";
            echo "<script>window.location.href='index.php';</script>";
        }
        
        else {
            echo "<script>alert('Incorrect password');</script>";
        }
    } else {
        echo "<script>alert('User not found');</script>";
    }
}

?>
