<?php
include("../includes/connect.php");
include("../functions/common_function.php");
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
    <style>
        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        .custom-btn {
            border-radius: 12px;
            padding: 10px 20px;
            transition: background-color 0.3s ease-in-out, transform 0.2s;
            font-weight: bold;
            font-size: 15px;
            border: 0;
        }

        .custom-btn a {
            color: #fff;
            text-decoration: none;
            display: block;
        }


        .insert-product {
            background-color: #007bff;
        }

        /* Primary Blue */
        .view-product {
            background-color: #17a2b8;
        }

        /* Info Teal */
        .insert-category {
            background-color: #6f42c1;
        }

        /* Purple */
        .view-category {
            background-color: #20c997;
        }

        /* Light Green */
        .insert-brand {
            background-color: #fd7e14;
        }

        /* Orange */
        .view-brand {
            background-color: #e83e8c;
        }

        /* Pink */
        .all-orders {
            background-color: #28a745;
        }

        /* Green */
        .all-payments {
            background-color: #6610f2;
        }

        /* Indigo */
        .list-users {
            background-color: #343a40;
        }

        /* Dark Gray */
        .logout {
            background-color: #dc3545;
        }

        /* Red */

        .custom-btn:hover {
            transform: scale(1.04);
            filter: brightness(90%);
        }

        .product_img {
            width: 100px;
            object-fit: contain;
        }
    </style>
</head>

<body>
    <!-- navbar -->
    <div class="container-fluid p-0 ">
        <nav class="navbar navbar-expand-lg navbar-light bg-info">
            <div class="container-fluid">
                <img src="../logo.png" alt="" class="logo">
                <nav class="navbar navbar-expand-lg ">
                    <!-- <ul class="navbar-nav">
                        <li class="nav-item">
                          <?php
                            if (!isset($_SESSION['username'])) {
                                echo '<a href="#" class="nav-link fw-bold">Welcome Guest</a>';
                            } else {
                                echo '<a href="#" class="nav-link fw-bold">Welcome ' . $_SESSION['username'] . '</a>';
                            }
                            ?>


                               
                            </a>
                        </li>
                    </ul> -->
                    <ul class="navbar-nav">
                        <?php if (isset($_SESSION['admin_username'])): ?>
                            <li class="nav-item"><a class="nav-link fw-bold" href="#">Welcome, <?= $_SESSION['admin_username']; ?></a></li>
                            <li class="nav-item"><a class="nav-link fw-bold" href="logout.php">Logout</a></li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link fw-bold" href="admin_login.php">Login</a></li>
                            <li class="nav-item"><a class="nav-link fw-bold" href="admin_registration.php">Register</a></li>
                        <?php endif; ?>
                    </ul>

                </nav>
            </div>
        </nav>
        <div class="bg-light">
            <h3 class="text-center p-2">
                Manage details
            </h3>
        </div>
        <div class="col-md-12 bg-secondary p-1 d-flex align-items-center">
            <div class="p-3">
                <a href="#"><img src="./Iphone Boys Dp.jpeg" alt="" class="admin_image"></a>
                <!-- <p class="text-light text-center">
                    Admin Name
                </p> -->
                <p class="text-light text-center fw-bold">
                    <?php
                    if (!isset($_SESSION['admin_username'])) {
                        echo 'Admin';
                    } else {
                        echo $_SESSION['admin_username'];
                    }
                    ?>
                </p>

            </div>
            <div class="button text-center ">
                <button class="custom-btn insert-product  m-2 p-2 "><a href="insert_product.php" class="nav-link   my-1">Insert Products</a></button>
                <button class="custom-btn view-product  m-2 p-2"><a href="index.php?view_products" class="nav-link  my-1">View Products</a></button>
                <button class="custom-btn  insert-category  m-2 p-2"><a href="index.php?insert_category" class="nav-link  my-1">Insert Categories</a></button>
                <button class="custom-btn view-category  m-2 p-2"><a href="index.php?view_categories" class="nav-link  my-1">View Categories</a></button>
                <button class="custom-btn insert-brand  m-2 p-2"><a href="index.php?insert_brand" class="nav-link my-1">Insert brands</a></button>
                <button class="custom-btn view-brand  m-2 p-2"><a href="index.php?view_brands" class="nav-link my-1">View brands</a></button>
                <button class="custom-btn all-orders  m-2 p-2"><a href="index.php?list_orders" class="nav-link my-1">All orders</a></button>
                <button class="custom-btn all-payments  m-2 p-2"><a href="index.php?list_payments" class="nav-link  my-1">All Payments</a></button>
                <button class="custom-btn list-users  m-2 p-2"><a href="index.php?list_users" class="nav-link  my-1">List users</a></button>
                <!-- <button class="custom-btn  logout  m-2 p-2"><a href="logout.php" class="nav-link  my-1">Logout</a></button> -->
                <button class="custom-btn insert-category m-2 p-2">
                    <a href="add_discount.php" class="nav-link my-1">Add Discount</a>
                </button>


            </div>

        </div>
    </div>
    <div class="container my-3">
        <?php
        if (isset($_GET['insert_category'])) {
            include('insert_categories.php');
        }
        if (isset($_GET['insert_brand'])) {
            include('insert_brands.php');
        }
        if (isset($_GET['view_products'])) {
            include('view_products.php');
        }
        if (isset($_GET['edit_products'])) {
            include('edit_products.php');
        }
        if (isset($_GET['delete_product'])) {
            include('delete_product.php');
        }
        if (isset($_GET['view_categories'])) {
            include('view_categories.php');
        }
        if (isset($_GET['view_brands'])) {
            include('view_brands.php');
        }
        if (isset($_GET['edit_category'])) {
            include('edit_category.php');
        }
        if (isset($_GET['edit_brands'])) {
            include('edit_brands.php');
        }
        if (isset($_GET['delete_category'])) {
            include('delete_category.php');
        }
       

        if (isset($_GET['delete_brands'])) {
            include('delete_brands.php');
        }
        if (isset($_GET['list_orders'])) {
            include('list_orders.php');
        }
        if (isset($_GET['list_payments'])) {
            include('list_payments.php');
        }
        if (isset($_GET['list_users'])) {
            include('list_users.php');
        }
        ?>
    </div>
    <!-- <div class="bg-info p-3 text-center footer">
        <p>All rights reserved &copy; Designed By Manvir-Singh 2025</p>
    </div> -->
    <?php
    include '../includes/footer.php';


    ?>

    </div>








    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</body>

</html>