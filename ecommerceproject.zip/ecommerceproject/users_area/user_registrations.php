<?php

include '../includes/connect.php';
include '../functions/common_function.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f8f9fa;
    }
    .form-container {
      max-width: 700px;
      margin: 50px auto;
      background: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    }
    .form-title {
      text-align: center;
      margin-bottom: 30px;
      font-weight: bold;
      color: #0d6efd;
    }
    @media (max-width: 576px) {
      .form-container {
        padding: 25px;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <div class="form-container">
    <h2 class="form-title">New User Registration</h2>
    <form action="" method="POST" enctype="multipart/form-data">
      
      <div class=" form-outline mb-3">
        <label for="user_username" class="form-control">Username</label>
        <input type="text" name="user_username" id="user_username" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="user_email" class="form-label">Email</label>
        <input type="email" name="user_email" class="form-control" required autocomplete="off">
      </div>

      <div class="mb-3">
        <label for="user_image" class="form-label">User Image</label>
        <input type="file" name="user_image" class="form-control" required  autocomplete="off">
      </div>

      <div class="mb-3">
      <label for="user_password" class="form-label">Password</label>
      <input type="password" name="user_password" id="user_password" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm Password</label>
        <input type="password" name="conf_user_password" class="form-control" required autocomplete="off">
      </div>

      <div class="mb-3">
        <label for="address" class="form-label">Address</label>
        <textarea name="user_address" class="form-control" rows="2" required autocomplete="off"></textarea>
      </div>

      <div class="mb-3">
        <label for="contact" class="form-label">Contact</label>
        <input type="text" name="user_contact" class="form-control" required autocomplete="off">
      </div>

      <div class="d-grid gap-2">
        <button type="submit" name="user_register" class="btn btn-primary">Register</button>
      </div>

      <p class="text-center mt-3">
        Already have an account? <a href="user_login.php">Login here</a>
      </p>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


<?php
if(isset($_POST['user_register'])){
$user_username=$_POST['user_username'];
$user_email=$_POST['user_email'];
$user_password=$_POST['user_password'];
$hash_password=password_hash($user_password,PASSWORD_DEFAULT);
$conf_user_password=$_POST['conf_user_password'];
$user_address=$_POST['user_address'];
$user_contact=$_POST['user_contact'];
$user_image=$_FILES['user_image']['name'];
$user_image_tmp=$_FILES['user_image']['tmp_name'];
$user_ip=getIPAddress();

//select query

$select_query="SELECT * FROM user_table where username='$user_username' or user_email='$user_email'";
$result=mysqli_query($conn,$select_query);
$row_count=mysqli_num_rows($result);
if($row_count>0){
  echo "<script>alert('Username and Email already exist')</script>";

}
else if($user_password!=$conf_user_password){
  echo "<script>alert('Password do not match')</script>";
}
else{


move_uploaded_file($user_image_tmp,"./user_images/$user_image");


$insert_query="INSERT INTO user_table(username,	user_email,	user_password,	user_image,	user_ip,	user_address,	user_mobile) VALUES(
'$user_username', '$user_email', '$hash_password','$user_image', '$user_ip', '$user_address','$user_contact')";
$sql_execute=mysqli_query($conn,$insert_query);


}
//selecting cart items
$select_cart_items="select * from cart_details where ip_address='$user_ip'";
$result_cart=mysqli_query($conn,$select_cart_items);
$rows_count=mysqli_num_rows($result_cart);
if($rows_count>0){
  $_SESSION['username']=$user_username;
  echo "<script>alert('You have items in your cart')</script>";
  echo "<script>window.open('checkout.php','_self')</script>";

}
else{
  echo "<script>window.open('../index.php','_self')</script>";
}
}


?>
