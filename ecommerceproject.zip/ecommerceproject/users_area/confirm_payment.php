<?php
include ('../includes/connect.php');
session_start();
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    
    
    // Fetch order details from the database
    $select_data="SELECT * FROM user_orders WHERE order_id='$order_id'";
    $result=mysqli_query($conn, $select_data);
    $row_fetch=mysqli_fetch_assoc($result);
    
    // Store the fetched data in variables
    $invoice_number = $row_fetch['invoice_number'];
    $amount_due = $row_fetch['amount_due'];
   
    
    
}
if(isset($_POST['confirm_payment'])){

    $invoice_number = $_POST['invoice_number'];
    $amount = $_POST['amount_due'];
    $payment_mode = $_POST['payment_mode'];

    $insert_query = "INSERT INTO user_payments (order_id, invoice_number, amount, payment_mode)
                     VALUES ('$order_id', '$invoice_number', '$amount', '$payment_mode')";
    
    $result = mysqli_query($conn, $insert_query);

    if($result){
        echo "<h3 class='text-center text-light'>Successfully completed the payment</h3>";
        echo "<script>window.open('profile.php?my_orders','_self');</script>";
        

    
}
$update_orders="update user_orders set order_status='complete' where order_id='$order_id'";
$result_orders=mysqli_query($conn, $update_orders);

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
</head>

<body class="bg-secondary">
    <div class="container my-5">
        

        <!-- Payment Form -->
        <form method="post">
            <div class="form-outline my-4 text-center w-50 m-auto">
                <label for="invoice_number" class="text-light">Invoice Number</label>
                <input type="text" class="form-control w-50 m-auto" name="invoice_number" value="<?php echo $invoice_number; ?>" readonly>
            </div>
            <div class="form-outline my-4 text-center w-50 m-auto">
                <label for="amount_due" class="text-light">Amount Due</label>
                <input type="text" class="form-control w-50 m-auto" name="amount_due" value="<?php echo $amount_due; ?>" readonly>
            </div>
            <div class="form-outline my-4 text-center w-50 m-auto">
                <select name="payment_mode" class="form-select w-50 m-auto">
                    <option>Select Payment Mode</option>
                    <option>UPI</option>
                    <option>NetBanking</option>
                    <option>PayPal</option>
                    <option>Cash on Delivery</option>
                    <option>Pay offline</option>
                </select>
            </div>
            <div class="form-outline my-4 text-center w-50 m-auto">
                <input type="submit" class="bg-info py-2 px-3 border-0" name="confirm_payment" value="Confirm">
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</body>

</html>
