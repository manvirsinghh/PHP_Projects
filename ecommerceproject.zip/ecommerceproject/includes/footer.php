<div class="bg-info p-3 text-center">
            <p>All rights reserved &copy; Designed By Manvir-Singh 2025</p>
        </div>