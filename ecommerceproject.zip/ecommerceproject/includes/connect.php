<?php
$servername="localhost";
$username="root";
$password="";
$dbname="Mystore";
$conn = new mysqli($servername, $username, $password, $dbname);

//  if(!$conn){
//      die("connection failed:".mysqli_connect_error());
// }

//  else{
//     echo "success ,database connected";
// }
?>