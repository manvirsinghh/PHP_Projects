-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 21, 2025 at 01:48 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Mystore`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'swiggy'),
(2, 'Zomato'),
(3, 'Mc Donalds'),
(4, 'Amazon');

-- --------------------------------------------------------

--
-- Table structure for table `cart_details`
--

CREATE TABLE `cart_details` (
  `product_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(20) NOT NULL,
  `category_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_title`) VALUES
(2, 'fruits1'),
(6, 'Juice'),
(9, 'Milk Products'),
(12, 'Shoes'),
(13, 'Sketch books');

-- --------------------------------------------------------

--
-- Table structure for table `orders_pending`
--

CREATE TABLE `orders_pending` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(255) NOT NULL,
  `order_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders_pending`
--

INSERT INTO `orders_pending` (`order_id`, `user_id`, `invoice_number`, `product_id`, `quantity`, `order_status`) VALUES
(2, 1, 1078609261, 6, 1, 'pending'),
(3, 1, 268241620, 6, 1, 'pending'),
(4, 1, 886491093, 6, 4, 'pending'),
(5, 1, 1530780804, 6, 1, 'pending'),
(6, 1, 1615269310, 6, 1, 'pending'),
(7, 1, 952444887, 6, 1, 'pending'),
(8, 1, 1390105349, 5, 1, 'pending'),
(9, 1, 801758433, 6, 1, 'pending'),
(10, 1, 2136642778, 6, 1, 'pending'),
(11, 2, 1128370910, 6, 1, 'pending'),
(12, 2, 2072908336, 1, 1, 'pending'),
(13, 2, 273215837, 6, 1, 'pending'),
(14, 3, 2133910939, 5, 2, 'pending'),
(15, 3, 105481982, 6, 1, 'pending'),
(16, 3, 948835037, 6, 1, 'pending'),
(17, 4, 551439972, 5, 1, 'pending'),
(18, 4, 335321366, 6, 2, 'pending'),
(19, 4, 346801705, 6, 1, 'pending'),
(20, 2, 1656311474, 6, 1, 'pending'),
(21, 4, 1710535211, 5, 1, 'pending'),
(22, 2, 1456085601, 6, 4, 'pending'),
(23, 2, 1806489200, 6, 1, 'pending'),
(24, 3, 1154397517, 1, 1, 'pending'),
(25, 2, 1384212223, 6, 2, 'pending'),
(26, 3, 2141206774, 6, 1, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `product_keywords` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `product_image1` varchar(255) NOT NULL,
  `product_image2` varchar(255) NOT NULL,
  `product_image3` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_description`, `product_keywords`, `category_id`, `brand_id`, `product_image1`, `product_image2`, `product_image3`, `product_price`, `date`, `status`) VALUES
(1, 'Fresh Mango', 'Mango is king of fruits', 'mango,fresh mango,green mango,zomato,fresh', 2, 2, 'mango.jpeg', 'fresh mango.jpeg', 'raw mango.jpeg', '200', '2025-04-11 05:09:05', 'true'),
(5, 'Capsicum2', 'Capsicum is very good for health.It contains all nutrients', 'capsicum,green capsicum, yellow capsicum, fresh capsicum', 8, 5, 'download.jpeg', 'apple.jpeg', 'lichi.jpeg', '1000', '2025-04-20 19:05:02', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `user_orders`
--

CREATE TABLE `user_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount_due` int(255) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `total_products` int(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_orders`
--

INSERT INTO `user_orders` (`order_id`, `user_id`, `amount_due`, `invoice_number`, `total_products`, `order_date`, `order_status`) VALUES
(1, 1, 125, 477325628, 2, '2025-04-19 03:50:15', 'pending'),
(2, 1, 0, 675948514, 0, '2025-04-19 03:50:51', 'pending'),
(3, 1, 225, 1078609261, 2, '2025-04-19 03:54:54', 'pending'),
(4, 1, 325, 268241620, 3, '2025-04-19 04:10:20', 'pending'),
(5, 1, 500, 886491093, 2, '2025-04-19 04:23:34', 'pending'),
(6, 1, 25, 1530780804, 1, '2025-04-19 04:25:06', 'pending'),
(7, 1, 125, 1615269310, 2, '2025-04-19 04:25:55', 'pending'),
(8, 1, 225, 952444887, 2, '2025-04-19 04:26:23', 'pending'),
(9, 1, 300, 1390105349, 2, '2025-04-19 04:46:27', 'pending'),
(10, 1, 225, 801758433, 2, '2025-04-19 04:48:26', 'pending'),
(11, 1, 0, 1834036687, 0, '2025-04-19 04:49:57', 'pending'),
(12, 1, 225, 2136642778, 2, '2025-04-19 04:53:31', 'pending'),
(13, 1, 0, 1303155478, 0, '2025-04-19 05:05:30', 'pending'),
(14, 3, 0, 1096423613, 0, '2025-04-19 21:59:21', 'complete'),
(15, 2, 25, 1128370910, 1, '2025-04-19 20:10:00', 'complete'),
(16, 2, 200, 2072908336, 1, '2025-04-19 20:27:08', 'complete'),
(17, 2, 225, 273215837, 2, '2025-04-19 20:29:54', 'complete'),
(18, 3, 600, 2133910939, 2, '2025-04-19 06:04:47', 'pending'),
(19, 3, 325, 105481982, 3, '2025-04-19 06:06:38', 'pending'),
(20, 3, 225, 948835037, 2, '2025-04-19 06:07:33', 'pending'),
(21, 4, 300, 551439972, 2, '2025-04-19 20:31:14', 'complete'),
(22, 4, 450, 335321366, 2, '2025-04-19 18:14:19', 'pending'),
(23, 4, 325, 346801705, 3, '2025-04-19 18:16:34', 'pending'),
(24, 4, 0, 2097839742, 0, '2025-04-19 18:17:10', 'pending'),
(25, 2, 25, 1656311474, 1, '2025-04-19 18:18:16', 'pending'),
(26, 4, 100, 1710535211, 1, '2025-04-19 18:27:03', 'pending'),
(27, 2, 100, 1456085601, 1, '2025-04-19 18:27:44', 'pending'),
(28, 2, 25, 1806489200, 1, '2025-04-19 18:28:28', 'pending'),
(29, 3, 200, 1154397517, 1, '2025-04-19 18:32:37', 'pending'),
(30, 2, 50, 1384212223, 1, '2025-04-19 19:53:11', 'pending'),
(31, 3, 25, 2141206774, 1, '2025-04-19 21:59:02', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `user_payments`
--

CREATE TABLE `user_payments` (
  `paymemt_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_number` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_payments`
--

INSERT INTO `user_payments` (`paymemt_id`, `order_id`, `invoice_number`, `amount`, `payment_mode`, `date`) VALUES
(1, 15, 1128370910, 25, 'PayPal', '2025-04-19 20:10:00'),
(2, 16, 2072908336, 200, 'NetBanking', '2025-04-19 20:27:08'),
(3, 17, 273215837, 225, 'Cash on Delivery', '2025-04-19 20:29:54'),
(4, 21, 551439972, 300, 'Pay offline', '2025-04-19 20:31:14'),
(5, 14, 1096423613, 0, 'UPI', '2025-04-19 21:59:21');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_image` varchar(100) NOT NULL,
  `user_ip` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_mobile` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `username`, `user_email`, `user_password`, `user_image`, `user_ip`, `user_address`, `user_mobile`) VALUES
(2, 'jasraj', 'jasraj123@gmail.com', '$2y$10$M24W/U4K0vLrZoi7xHRmaus0FwDntylg4jaj4MCU3vctS/qJi/rVq', 'turbanboy copy.jpeg', '::1', 'bathinda', 123456789),
(3, 'manjot', 'manjot@gmail.com', '$2y$10$c3rTmvtOShhM4eGSfF5orenpG0s5cmCw3x4mzDNwYqG2MUJoowTqi', 'turbanboy.jpeg', '::1', 'ldh', 987654321);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart_details`
--
ALTER TABLE `cart_details`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders_pending`
--
ALTER TABLE `orders_pending`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_orders`
--
ALTER TABLE `user_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `user_payments`
--
ALTER TABLE `user_payments`
  ADD PRIMARY KEY (`paymemt_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders_pending`
--
ALTER TABLE `orders_pending`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_orders`
--
ALTER TABLE `user_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `user_payments`
--
ALTER TABLE `user_payments`
  MODIFY `paymemt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
