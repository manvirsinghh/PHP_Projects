<?php
include("config.php");
include 'header.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Fetch camp registrations along with event details
$query = "SELECT camp_registrations.*, events.blood_camp_name 
          FROM camp_registrations 
          JOIN events ON camp_registrations.event_id = events.id 
          ORDER BY camp_registrations.registered_at DESC";

$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Camp Registrations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container mt-5">
        <h2 class="text-center text-danger fw-bold">🩸 Blood Camp Registrations</h2>

        <div class="table-responsive mt-4">
            <table class="table table-bordered table-striped text-center align-middle">
                <thead class="table-dark text-white">
                    <tr>
                        <th>ID</th>
                        <th>Camp Name</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Blood Group</th>
                        <th>City</th>
                        <th>Registered At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><span class="badge bg-primary"><?php echo $row['blood_camp_name']; ?></span></td>
                            <td class="fw-bold"><?php echo $row['name']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['phone']; ?></td>
                            <td><span class="badge bg-danger"><?php echo $row['blood_group']; ?></span></td>
                            <td><?php echo $row['city']; ?></td>
                            <td><?php echo date("d M Y, h:i A", strtotime($row['registered_at'])); ?></td>
                            <td>
                                <a href="camp_registrations_delete.php?id=<?php echo $row['id']; ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Are you sure you want to delete this registration?');">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
