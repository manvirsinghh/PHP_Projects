<?php 
include("config.php");
 if(isset($_GET['id'])){
    $id=$_GET['id'];


    $sql="DELETE FROM events WHERE id='$id'";
    if($conn->query($sql)===TRUE){
     header("location:upcoming_events.php");

    }
    
        else{
            echo "Error:" .$sql ."<br>" . $conn->error;
        }
    }
 $CONN->close();


?>