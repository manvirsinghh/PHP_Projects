<?php
include("header.php");
$sql = "SELECT * FROM events  ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donation Camps</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        
        @media (max-width: 768px) {
            .table th, .table td {
                font-size: 12px;
                padding: 5px;
            }
        }
    </style>
</head>
<body class="bg-light">

<div class="container mt-4">
    <div class="row justify-content-between align-items-center">
        <div class="col-md-6">
            <h2 class="text-danger">Blood Donation Camp</h2>
        </div>
        <div class="col-md-6  text-end">
            <a href="add_event.php" class="btn btn-primary">+ Add Camp</a>
        </div>
    </div>

    <div class="card p-3 shadow-sm mt-3">
        <div class="row">
            <div class="col-12">
                <table class="table table-bordered table-striped text-center align-middle">
                    <thead class="table-dark">
                        <tr>
                            
                            <th>Blood Camp Name</th>
                            <th>Location</th>
                            <th>Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    
                                    <td>".$row['blood_camp_name']."</td>
                                    <td>".$row['location']."</td>
                                    <td>".$row['calendar']."</td>
                                    <td>".$row['starttime']."</td>
                                    <td>".$row['endtime']."</td>
                                    <td>
                                        <img src='../uploads/".$row['image']."' alt='Event Image' class='img-fluid rounded' style='max-width: 60px; height: auto;'>
                                    </td>
                                    <td>
                                        <div class='d-flex flex-column flex-md-row justify-content-center gap-1'>
                                            <a href='edit.php?id=".$row['id']."' class='btn btn-warning btn-sm w-100 w-md-auto'>Edit</a>
                                            <a href='delete.php?id=".$row['id']."' class='btn btn-danger btn-sm w-100 w-md-auto'>Delete</a>
                                        </div>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-muted text-center'>No data found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
