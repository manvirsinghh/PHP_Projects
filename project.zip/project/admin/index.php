<?php 
session_start();
include("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">

   <div class="container">
      <div class="row justify-content-center">
         <div class="col-md-4 col-sm-8 col-10">
            <div class="card shadow p-4">
               <h3 class="text-center text-primary mb-3">Admin Login</h3>

               <form method="post">
                  <div class="mb-3">
                     <label class="form-label">Username</label>
                     <input type="text" name="username" class="form-control" required>
                  </div>

                  <div class="mb-3">
                     <label class="form-label">Password</label>
                     <input type="password" name="password" class="form-control" required>
                  </div>

                  <button type="submit" class="btn btn-primary w-100">Login</button>

                  <?php 
                  if($_SERVER["REQUEST_METHOD"] == "POST"){
                     $username = $_POST['username'];
                     $password = $_POST['password'];

                     $sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
                     $result = $conn->query($sql);

                     if($result->num_rows > 0){
                         $_SESSION["username"] = $username;
                         header("location:upcoming_events.php");
                         exit();
                     } else {
                         echo "<div class='alert alert-danger mt-3 text-center'>Invalid Credentials</div>";
                     }
                  }
                  ?>
               </form>
            </div>
         </div>
      </div>
   </div>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
