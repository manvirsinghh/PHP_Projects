<?php 
include("config.php");
 if(isset($_GET['id'])){
    $id=$_GET['id'];


    $sql="DELETE FROM blood_seeker_registration WHERE id='$id'";
    if($conn->query($sql)===TRUE){
    header("location:seeker_fetch.php");

    }
    
        else{
            echo "Error:" .$sql ."<br>" . $conn->error;
        }
    }
 


?>