
<?php 
include("config.php");
session_start();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Blood Bank</title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="../img/drop.png" type="image/x-icon">
</head>
<body>

<nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="lbb.png" alt="Logo" height="40"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="upcoming_events.php">Upcoming Events</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="register_fetch.php">Donor Registration list</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link" href="donor_details_fetch.php">Donor details</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="seeker_fetch.php">Blood Seeker details</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="emergency_fetch.php">Blood Emergency</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="camp_list.php">camp registration</a>
        </li>
      </ul>
      <a class="btn btn-outline-success" type="submit" href="logout.php">Logout</a>
      <form class="d-flex">
        
      </form>
    </div>
  </div>
</nav>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
