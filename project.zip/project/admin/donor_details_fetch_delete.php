<?php 
include("config.php");
 if(isset($_GET['id'])){
    $id=$_GET['id'];


    $sql="DELETE FROM donor_details WHERE id='$id'";
    if($conn->query($sql)===TRUE){
     header("location:donor_details_fetch.php");

    }
    
        else{
            echo "Error:" .$sql ."<br>" . $conn->error;
        }
    }
 


?>