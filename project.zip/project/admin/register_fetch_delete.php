<?php 
include("config.php");
 if(isset($_GET['id'])){
    $id=$_GET['id'];


    $sql="DELETE FROM blood_donor_registration WHERE id='$id'";
    if($conn->query($sql)===TRUE){
    header("location:register_fetch.php");
    }
    
        else{
            echo "Error:" .$sql ."<br>" . $conn->error;
        }
    }
 


?>