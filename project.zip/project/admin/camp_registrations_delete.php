<?php
include("config.php");
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid request.");
}

$id = intval($_GET['id']); // Convert to integer to prevent SQL injection

// Delete query (without bind_param)
$query = "DELETE FROM camp_registrations WHERE id = $id";
$result = mysqli_query($conn, $query);

if ($result) {
    header("Location: camp_list.php?");
    exit();
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>
