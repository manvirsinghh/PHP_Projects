<?php 
include("config.php");
 if(isset($_GET['id'])){
    $id=$_GET['id'];


    $sql="DELETE FROM contact  WHERE id='$id'";
    if($conn->query($sql)===TRUE){
     echo "record deleted successfully";

    }
    
        else{
            echo "Error:" .$sql ."<br>" . $conn->error;
        }
    }
 


?>