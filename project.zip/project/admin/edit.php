<?php
include("config.php");

if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT * FROM events WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
 
   
    $blood_camp_name = $_POST['blood_camp_name'];
    $location = $_POST['location'];
    $calendar = $_POST['calendar'];
    $starttime = $_POST['starttime'];
    $endtime = $_POST['endtime'];
    $image=$_FILES['image']['name'];

    if($image){

        $target="../uploads/". basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
        $sql = "UPDATE events SET blood_camp_name='$blood_camp_name', location='$location', calendar='$calendar', starttime='$starttime' ,endtime='$endtime', image='$image' WHERE id='$id'";
      
   
    }
    else{

         $sql = "UPDATE events SET blood_camp_name='$blood_camp_name', location='$location', calendar='$calendar', starttime='$starttime' ,endtime='$endtime' WHERE id='$id'";
    }

    // $sql = "UPDATE events SET blood_camp_name='$blood_camp_name', location='$location', calendar='$calendar', starttime='$starttime' ,endtime='$endtime', image='$image' WHERE id='$id'";
    
    if($conn->query($sql) === TRUE){
        echo "Record updated successfully";
        header("Location: upcoming_events.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card p-4 ">
        <h2 class="text-center mb-4"> Blood Donation Camp</h2>
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Blood Camp Name</label>
                <input type="text" class="form-control" name="blood_camp_name" value="<?php echo $row['blood_camp_name']; ?>"> 
            </div>
            <div class="mb-3">
                <label class="form-label">Location</label>
                <input type="text" class="form-control" name="location" value="<?php echo $row['location']; ?>"> 
            </div>
            <div class="mb-3">
                <label class="form-label">Date</label>
                <input type="date" class="form-control" name="calendar" value="<?php echo $row['calendar']; ?>"> 
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Start Time</label>
                    <input type="time" class="form-control" name="starttime" value="<?php echo $row['starttime'];?>"> 
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">End Time</label>
                    <input type="time" class="form-control" name="endtime" value="<?php echo $row['endtime'];?>"> 
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Image</label>
                    <input type="file" class="form-control" name="image"  accept="image/png, image/jpeg , image/jpg">
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Add Event</button>
        </form>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
